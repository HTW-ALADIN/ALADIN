self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fee3f052be77fcb8f2a4915162ba10fb",
    "url": "/aladin.ico"
  },
  {
    "revision": "6957dad147c497573939",
    "url": "/css/app.c220275c.css"
  },
  {
    "revision": "9443742475d3a480192a",
    "url": "/css/configurator.8ac02f78.css"
  },
  {
    "revision": "600ea6060f7c1ab3f5ce",
    "url": "/css/configurator~replay~task.571d9b1f.css"
  },
  {
    "revision": "d48e92fa771792ef2491",
    "url": "/css/configurator~replay~task~test.db0dad16.css"
  },
  {
    "revision": "5b9acbc4415639a0fbf7",
    "url": "/css/replay.8f58d5e3.css"
  },
  {
    "revision": "225e7909a8cd997fce88",
    "url": "/css/replayoverview.10451376.css"
  },
  {
    "revision": "ec77990619a4aed77201",
    "url": "/css/settings.b2278f94.css"
  },
  {
    "revision": "36207fe1821d18f9e4fe",
    "url": "/css/task.cd2cf64f.css"
  },
  {
    "revision": "7084b881cb3ed33f2fcc",
    "url": "/css/test.519307b0.css"
  },
  {
    "revision": "7145ea06d6b66998fd56e3d31779965c",
    "url": "/img/drag_arrow.webp"
  },
  {
    "revision": "2c4806eb414ae3f3822375791769960e",
    "url": "/img/fake_cursor.png"
  },
  {
    "revision": "0c32b7c9f7fe049f968b5a3a1bdb77aa",
    "url": "/img/lightbulb.png"
  },
  {
    "revision": "64558b0e0d7cd2b3f3356066de5e3ecb",
    "url": "/img/lightbulb_on.png"
  },
  {
    "revision": "f62185768884d5a13c58503f3c45f398",
    "url": "/img/loading_spinner.svg"
  },
  {
    "revision": "1d7f55ec6736a6b6cc7c4ff527ae5cf8",
    "url": "/img/tasks/gozintograph/graphTraversal.png"
  },
  {
    "revision": "6fb6f77702bb390bdf357e6d8fcf2548",
    "url": "/img/tasks/gozintograph/matmul.png"
  },
  {
    "revision": "3800335fb63d5a7cfa9ad5c75050d4a6",
    "url": "/img/tasks/gozintograph/vaszonyi.png"
  },
  {
    "revision": "2511b66b3066a6b539b1f0516ec9cdc3",
    "url": "/img/tasks/scheduling/gantt_diagram.png"
  },
  {
    "revision": "309c28ab39e56869822357f65f2f77a9",
    "url": "/img/tasks/scheduling/netzplan.png"
  },
  {
    "revision": "cced674a9a0329eda082cfe830778424",
    "url": "/index.html"
  },
  {
    "revision": "6957dad147c497573939",
    "url": "/js/app.92633073.js"
  },
  {
    "revision": "ad3226a045f69c95d2db",
    "url": "/js/chunk-vendors.db7964e3.js"
  },
  {
    "revision": "9443742475d3a480192a",
    "url": "/js/configurator.971bd4b7.js"
  },
  {
    "revision": "600ea6060f7c1ab3f5ce",
    "url": "/js/configurator~replay~task.8d439913.js"
  },
  {
    "revision": "d48e92fa771792ef2491",
    "url": "/js/configurator~replay~task~test.7516c169.js"
  },
  {
    "revision": "e21c758de130f6594cb2f5ea1992564b",
    "url": "/js/graphvizlib.wasm"
  },
  {
    "revision": "5b9acbc4415639a0fbf7",
    "url": "/js/replay.0082b0be.js"
  },
  {
    "revision": "225e7909a8cd997fce88",
    "url": "/js/replayoverview.a3e6d74a.js"
  },
  {
    "revision": "ec77990619a4aed77201",
    "url": "/js/settings.c4afe447.js"
  },
  {
    "revision": "36207fe1821d18f9e4fe",
    "url": "/js/task.97372140.js"
  },
  {
    "revision": "7084b881cb3ed33f2fcc",
    "url": "/js/test.042943d1.js"
  },
  {
    "revision": "4b14c64efaf846819b9a229b4193c8b7",
    "url": "/manifest.json"
  },
  {
    "revision": "2af015238e3b29ac88b0a902df79bdbc",
    "url": "/mathlex.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);